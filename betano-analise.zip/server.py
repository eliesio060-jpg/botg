from __future__ import annotations

import json
import os
import pathlib
from http.server import BaseHTTPRequestHandler, HTTPServer
from typing import Tuple
from urllib.parse import urlparse

import cloudscraper

API_URL = "https://www.betano.bet.br/api/virtuals/resultsdata/?leagueId=204676&req=la,s,stnf,c,mb"
HOST = "0.0.0.0"  # Permite acesso externo
PORT = int(os.environ.get("PORT", 8002))  # Render define a porta
BASE_DIR = pathlib.Path(__file__).parent


def fetch_results() -> Tuple[int, str]:
    """Fetch and process JSON from Betano using cloudscraper."""
    try:
        scraper = cloudscraper.create_scraper()
        resp = scraper.get(API_URL, timeout=15)
        if resp.status_code != 200:
            return resp.status_code, json.dumps({"error": f"API returned {resp.status_code}"})
        
        data = resp.json()
        processed = []
        for res in data.get('data', {}).get('results', []):
            league_name = res.get('leagueName', 'Liga')
            events = []
            for ev in res.get('events', []):
                parts = ev.get('displayNameParts', [])
                home = parts[0].get('name', '') if len(parts) > 0 else ''
                away = parts[1].get('name', '') if len(parts) > 1 else ''
                
                stats = {s.get('statisticsType'): s.get('value', {}).get('score') for s in ev.get('statistics', [])}
                ft = f"{stats.get('FullTimeHomeTeam','?')}-{stats.get('FullTimeAwayTeam','?')}"
                ht = f"{stats.get('HalfTimeHomeTeam','?')}-{stats.get('HalfTimeAwayTeam','?')}"
                
                events.append({
                    'home': home,
                    'away': away,
                    'score': {'fullTime': ft, 'halfTime': ht}
                })
            
            processed.append({
                'leagueName': league_name,
                'events': events
            })
        
        return 200, json.dumps(processed, ensure_ascii=False)
    except Exception as exc:
        return 500, json.dumps({"error": str(exc)})


def guess_type(path: pathlib.Path) -> str:
    if path.suffix == ".html":
        return "text/html; charset=utf-8"
    if path.suffix == ".css":
        return "text/css; charset=utf-8"
    if path.suffix == ".js":
        return "application/javascript; charset=utf-8"
    if path.suffix == ".json":
        return "application/json; charset=utf-8"
    return "text/plain; charset=utf-8"


class Handler(BaseHTTPRequestHandler):
    def _set_cors(self) -> None:
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")

    def do_OPTIONS(self):  # noqa: N802
        self.send_response(200)
        self._set_cors()
        self.end_headers()

    def do_GET(self):  # noqa: N802
        if self.path.startswith("/api/results"):
            self.handle_api()
            return
        self.handle_static()

    def handle_api(self) -> None:
        try:
            status, body = fetch_results()
            self.send_response(status)
            self._set_cors()
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(body.encode())))
            self.end_headers()
            self.wfile.write(body.encode())
        except (BrokenPipeError, ConnectionAbortedError):
            pass  # Cliente fechou conexão, ignorar

    def handle_static(self) -> None:
        parsed = urlparse(self.path)
        rel_path = parsed.path.lstrip("/") or "index.html"
        target = (BASE_DIR / rel_path).resolve()
        if not str(target).startswith(str(BASE_DIR.resolve())):
            self.send_error(403)
            return
        if not target.exists() or target.is_dir():
            self.send_error(404)
            return
        content_type = guess_type(target)
        data = target.read_bytes()
        self.send_response(200)
        self._set_cors()
        self.send_header("Content-Type", content_type)
        self.send_header("Cache-Control", "no-cache, no-store, must-revalidate")
        self.send_header("Pragma", "no-cache")
        self.send_header("Expires", "0")
        self.end_headers()
        self.wfile.write(data)


if __name__ == "__main__":
    server = HTTPServer((HOST, PORT), Handler)
    print(f"Servidor rodando em http://0.0.0.0:{PORT}")
    print("Pressione Ctrl+C para parar.")
    server.serve_forever()
